"""File docstring"""


def valami():
    """Function docstring"""
    print("valami")
