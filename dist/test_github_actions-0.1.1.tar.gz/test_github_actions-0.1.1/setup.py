# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['test_github_actions']

package_data = \
{'': ['*']}

install_requires = \
['black>=23.12.1,<24.0.0',
 'matplotlib',
 'pylint>=3.0.3,<4.0.0',
 'setuptools>=69.0.3,<70.0.0']

setup_kwargs = {
    'name': 'test_github_actions',
    'version': '0.1.1',
    'description': '',
    'long_description': '',
    'author': 'AbrahamPapp',
    'author_email': 'pabris97@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
